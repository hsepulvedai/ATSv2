import { Component, OnInit } from '@angular/core';
import { JobService } from 'src/app/shared/services/job.service';
import { ActivatedRoute, Router } from '@angular/router';
import { IJob } from 'src/app/shared/models/job.model';
import { ModalService } from 'src/app/shared/services/modal.service';


@Component({
  selector: 'app-offer-info',
  templateUrl: './offer-info.component.html',
  styleUrls: ['./offer-info.component.css']
})
export class OfferInfoComponent implements OnInit {

  constructor(private jobService:JobService, private route:ActivatedRoute,
    private router:Router,   private modalService: ModalService) { }

    closeResult: string;

  job:IJob
  jobLoaded:Promise<any>

  ngOnInit() {

    const id = +this.route.snapshot.paramMap.get('id');

    this.jobService.showJobOfferDetail(id)
      .subscribe((data: IJob) => {
        this.job = data['Data'][0];

        if (this.job == undefined)
          this.router.navigate(['jobs'])
        // Setting the Promise as resolved after I have the needed data
        // to allow loading data into DOM
        console.log(this.job)
        this.jobLoaded = Promise.resolve(true);
      });
  }

  openModal(content) {
    this.modalService.openModal(content);
  }

}
