import { Component, OnInit } from '@angular/core';
import { Skill } from 'src/app/shared/models/skill';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { IJobType } from 'src/app/shared/models/job_type.model';
import { IJobCategory } from 'src/app/shared/models/job_category.model';
import { JobCategoryService } from 'src/app/shared/services/job-category.service';
import { JobTypeService } from 'src/app/shared/services/job-type.service';
import { JobService } from 'src/app/shared/services/job.service';
import { IJob } from 'src/app/shared/models/job.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-offer-create',
  templateUrl: './offer-create.component.html',
  styleUrls: ['./offer-create.component.css']
})
export class OfferCreateComponent implements OnInit {

  DEFAULT_REQ = true;
  skillWeight = 2;

  skillInput: string
  skills: Skill[] = [];
  applicationSkills: string[] = []

  jobCategories: IJobCategory[] = [];
  jobTypes: IJobType[] = [];
  // jobs: Job[] = [];
  createdJob: IJob

  pressedRemove: boolean = false;

  // Job form in step 1 of stepper
  newJobForm: FormGroup;

  constructor(private fb: FormBuilder, private jobCategoryService: JobCategoryService,
    private jobTypeService: JobTypeService, private jobService: JobService,
    private router:Router) { }

  ngOnInit() {

    //Initialize and validate the form
    this.newJobForm = this.fb.group({
      jobName: ['', Validators.required],
      jobCompany: ['', Validators.required],
      jobLocation: ['', Validators.required],
      jobCategory: ['', Validators.required],
      jobType: ['', Validators.required],
      jobDescription: ''
    })

    this.jobCategoryService.showCategories()
      .subscribe((data: IJobCategory[]) => {
        this.jobCategories = data['Data'];
        console.log(this.jobCategories)
      });

    this.jobTypeService.showTypes()
      .subscribe((data: IJobType[]) => {
        this.jobTypes = data['Data']
        console.log(this.jobTypes)
      });
  }

  // Helper method to change the view into the delete view.
  pressRemove() {
    this.pressedRemove = !this.pressedRemove
  }

  createJob(newJobForm, event):Promise<any> {

    // Validates the button pressed to
    // create the job
    var status: string;
    if (event.target.id == "draftBtn")
      status = "Draft";
    else
      status = "Active";

    // Validates if a skill is required
    var stringReq: string;
    this.skills.forEach(element => {
      if (element.Required)
        stringReq = "@";
      else
        stringReq = "";

      // Concatenates the skills in specified format.
      // Format: Requirement;Skill;Weight*25
      var skillStr = stringReq + ";" + element.Skill + ";" + (element.Weight * 25)
      this.applicationSkills.push(skillStr)
    });

    this.createdJob = {
      jobName: newJobForm.jobName,
      companyId: 1, // TODO: Change to get employee company
      jobCategory: newJobForm.jobCategory,
      jobType: newJobForm.jobType,
      jobDescription: newJobForm.jobDescription,
      jobStatus: 'Hiring', // TODO: Change to a dropdown or something
      jobSkills: this.applicationSkills.toString()
    }
      return Promise.resolve()
  }

  addJob(newJobForm, event) {

    this.createJob(newJobForm, event).then( data =>
      this.jobService.addJobMaintenance(this.createdJob)
      .subscribe(data => {
        console.log(this.createdJob)
        this.router.navigate(['/home/hr']);
        alert('Job was added');
      }, error => { console.error("Error: ", error) })
    )
  }

  // Removes a skill in the skills array according to
  // the index of the selected skill.
  removeSkill(skill) {

    var index = this.skills.indexOf(skill)

    for (var i = 0; i < this.skills.length; i++) {
      if (i === index) {
        this.skills.splice(i, 1);
      }
    }
  }

  // Adds the input value to the skills array when the 'Add Skill'
  // button is pressed.
  addSkillToList() {
    this.skills.push(new Skill(this.skillInput, this.DEFAULT_REQ, this.skillWeight));
    this.skillInput = ""
    // Refocus cursor to input box.
    document.getElementById("skillInputBox").focus();
  }

  // Changes the value of the skill requirement according to 'Requirement' 
  // checkbox changes. The value is a boolean.
  changeRequirement(skill, event) {

    var index = this.skills.indexOf(skill)

    for (var i = 0; i < this.skills.length; i++) {
      if (i === index) {
        skill.Required = event.checked
      }
    }
  }

  // Changes the value of the weight of the skill according to 'Weight' 
  // slider value changes. The value is a number 0-4.
  changeWeight(skill, event) {

    var index = this.skills.indexOf(skill);

    for (var i = 0; i < this.skills.length; i++) {
      if (i === index) {
        skill.Weight = event.value
      }
    }
  }
}
