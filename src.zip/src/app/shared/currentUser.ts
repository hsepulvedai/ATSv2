import { IUser } from "./models/user.model";

const currentUser:IUser = {
    id: 6,
    firstName: "Alex",
    lastName: "Grahambell",
    email: "phones@mail.com",
    password: "callmemaybe411",
    phone: "123-456-789",
    roleId: 4,
    createdBy: null,
    createdDate: new Date ("2018-08-22T14:20:44.91"),
    modifiedBy: null,
    modifiedDate: null,
    active: true
}