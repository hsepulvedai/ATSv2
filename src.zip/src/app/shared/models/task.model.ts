export interface ITask {
    applicantId?: number
    applicationId?: number, 
    applicantFirstName?: string,
    applicanLastName?: string,
    task?: string,
    createdData?:Date
}
