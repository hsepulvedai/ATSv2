export interface IStatus {
    status: string;
}