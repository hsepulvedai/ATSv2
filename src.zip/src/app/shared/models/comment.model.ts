export interface IComment {
    commentId?:number,
    commentData?:string,
    applicationId?:number,
    employeeId?:number,
    employeeFirstName?:string,
    employeeLastName?:string,
    createdDate?:Date
}