export interface IApplicantApply {
    applicantId: number,
      firstName: string,
      lastName: string,
      email: string,
      phone: string,
      addressLine:string,
      addressLine2: string,
      city:string,
      stateProvince:string,
      country:string,
      zipCode:string,
      comments?:string
}