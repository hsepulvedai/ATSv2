export interface IAction {
    actionId?:number,
    action?: string,
    applicationId?:number,
    status?: string;
    comments?: string,
    actionDate?: string
    employeeId?:number
}