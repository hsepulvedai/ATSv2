export interface IHRAction
 {
    actionId?: number,
    applicationId: number,
    action: string,
    comments: string,
    actionDate:Date,
}