export interface IActionInsert {
    applicationId: number,
    recruiterId: number, 
    action: string,
    status: string;
    comments: string,
    actionDate: string
}