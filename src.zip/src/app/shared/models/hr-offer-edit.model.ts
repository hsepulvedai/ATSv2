export interface IOfferHrEdit {
    applicationId?: number,
    jobId?:number,
    applicantId?:number,
    applicantFirstName?: string,
    applicantLastName?: string,
    applicationStatusId?: number,
    applicationStatus?: string,
    employeeId?: number,
    employeeFirstName?: string,
    employeeLastName?: string
}