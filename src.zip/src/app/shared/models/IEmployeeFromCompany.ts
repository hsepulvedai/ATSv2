export interface IEmployeeFromCompany
 {
    employeeId:number,
    companyId:number,
    employeeFullName:string,
}