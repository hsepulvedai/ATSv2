export interface IApplicationStatusInfo {
    jobTitle?: string,
    status?: string
}